print('hello, world.');input()
